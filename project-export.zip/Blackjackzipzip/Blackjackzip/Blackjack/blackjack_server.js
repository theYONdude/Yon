const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

app.get('/blackjack', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/imposter', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'imposter.html'));
});

app.get('/yon', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'yon.html'));
});

app.use(express.static(path.join(__dirname, 'public')));

const blackjackLobbies = new Map();
const imposterLobbies = new Map();
const yonLobbies = new Map();

const IMPOSTER_WORDS = [
  'Pizza', 'Coffee', 'Guitar', 'Ocean', 'Mountain', 'Sunset', 'Rainbow', 'Thunder',
  'Chocolate', 'Butterfly', 'Dragon', 'Castle', 'Wizard', 'Treasure', 'Diamond', 'Crown',
  'Phoenix', 'Unicorn', 'Vampire', 'Zombie', 'Robot', 'Spaceship', 'Planet', 'Galaxy',
  'Tornado', 'Volcano', 'Jungle', 'Desert', 'Iceberg', 'Waterfall', 'Forest', 'Beach',
  'Apple', 'Banana', 'Strawberry', 'Mango', 'Pineapple', 'Coconut', 'Lemon', 'Orange',
  'Tiger', 'Lion', 'Elephant', 'Giraffe', 'Penguin', 'Dolphin', 'Shark', 'Eagle',
  'Basketball', 'Football', 'Tennis', 'Hockey', 'Baseball', 'Swimming', 'Running', 'Cycling'
];

function generateLobbyCode() {
  return Math.random().toString(36).substring(2, 7).toUpperCase();
}

function createDeck() {
  const suits = ['♠', '♥', '♦', '♣'];
  const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck = [];
  
  for (let i = 0; i < 6; i++) {
    for (const suit of suits) {
      for (const value of values) {
        deck.push({ suit, value });
      }
    }
  }
  
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  
  return deck;
}

function getCardValue(card) {
  if (card.value === 'A') return 11;
  if (['J', 'Q', 'K'].includes(card.value)) return 10;
  return parseInt(card.value);
}

function calculateHandValue(hand) {
  let value = 0;
  let aces = 0;
  
  for (const card of hand) {
    const cardValue = getCardValue(card);
    value += cardValue;
    if (card.value === 'A') aces++;
  }
  
  while (value > 21 && aces > 0) {
    value -= 10;
    aces--;
  }
  
  return value;
}

function createBlackjackLobby(hostId, hostName) {
  const code = generateLobbyCode();
  blackjackLobbies.set(code, {
    code,
    hostId,
    players: new Map([[hostId, { id: hostId, name: hostName, money: 1000, bet: 0, hand: [], status: 'waiting' }]]),
    gameState: 'lobby',
    deck: [],
    dealerHand: [],
    currentPlayerIndex: 0,
    playersOrder: [hostId]
  });
  return code;
}

function startBlackjackGame(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.deck = createDeck();
  lobby.dealerHand = [];
  lobby.currentPlayerIndex = 0;
  lobby.gameState = 'betting';
  
  for (const player of lobby.players.values()) {
    player.hand = [];
    player.bet = 0;
    player.status = 'betting';
  }
  
  io.to(lobbyCode).emit('gameStarted', {
    gameState: 'betting'
  });
}

function dealInitialCards(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  for (const playerId of lobby.playersOrder) {
    const player = lobby.players.get(playerId);
    player.hand = [lobby.deck.pop(), lobby.deck.pop()];
    player.status = 'playing';
  }
  
  lobby.dealerHand = [lobby.deck.pop(), lobby.deck.pop()];
  lobby.gameState = 'playing';
  lobby.currentPlayerIndex = 0;
  
  broadcastBlackjackGameState(lobbyCode);
}

function broadcastBlackjackGameState(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
  
  const playerData = Array.from(lobby.players.values()).map(p => ({
    id: p.id,
    name: p.name,
    money: p.money,
    bet: p.bet,
    hand: p.hand,
    handValue: calculateHandValue(p.hand),
    status: p.status
  }));
  
  const dealerData = {
    hand: lobby.gameState === 'playing' ? [lobby.dealerHand[0], { suit: '?', value: '?' }] : lobby.dealerHand,
    handValue: lobby.gameState === 'results' ? calculateHandValue(lobby.dealerHand) : null
  };
  
  io.to(lobbyCode).emit('gameState', {
    players: playerData,
    dealer: dealerData,
    currentPlayerId: lobby.gameState === 'playing' ? currentPlayerId : null,
    gameState: lobby.gameState
  });
}

function nextBlackjackPlayer(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.currentPlayerIndex++;
  
  if (lobby.currentPlayerIndex >= lobby.playersOrder.length) {
    playDealerTurn(lobbyCode);
  } else {
    broadcastBlackjackGameState(lobbyCode);
  }
}

function playDealerTurn(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  let dealerValue = calculateHandValue(lobby.dealerHand);
  
  while (dealerValue < 17) {
    lobby.dealerHand.push(lobby.deck.pop());
    dealerValue = calculateHandValue(lobby.dealerHand);
  }
  
  resolveBlackjackRound(lobbyCode);
}

function resolveBlackjackRound(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const dealerValue = calculateHandValue(lobby.dealerHand);
  const dealerBusted = dealerValue > 21;
  
  for (const player of lobby.players.values()) {
    const playerValue = calculateHandValue(player.hand);
    const playerBusted = playerValue > 21;
    
    if (playerBusted) {
      player.status = 'lost';
    } else if (dealerBusted) {
      player.money += player.bet * 2;
      player.status = 'won';
    } else if (playerValue > dealerValue) {
      player.money += player.bet * 2;
      player.status = 'won';
    } else if (playerValue === dealerValue) {
      player.money += player.bet;
      player.status = 'push';
    } else {
      player.status = 'lost';
    }
  }
  
  lobby.gameState = 'results';
  broadcastBlackjackGameState(lobbyCode);
  
  setTimeout(() => {
    startBlackjackGame(lobbyCode);
  }, 5000);
}

function createImposterLobby(hostId, hostName) {
  const code = generateLobbyCode();
  imposterLobbies.set(code, {
    code,
    hostId,
    players: new Map([[hostId, { id: hostId, name: hostName, isImposter: false, clue: '', vote: null }]]),
    gameState: 'lobby',
    playersOrder: [hostId],
    word: '',
    imposterId: null,
    currentClueIndex: 0,
    votes: new Map(),
    revealedImposter: null
  });
  return code;
}

function startImposterGame(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) {
    console.log('startImposterGame: lobby not found for code', lobbyCode);
    return;
  }
  
  console.log('Starting Imposter game for lobby:', lobbyCode);
  console.log('Players:', Array.from(lobby.players.keys()));
  
  lobby.word = IMPOSTER_WORDS[Math.floor(Math.random() * IMPOSTER_WORDS.length)];
  const randomIndex = Math.floor(Math.random() * lobby.playersOrder.length);
  lobby.imposterId = lobby.playersOrder[randomIndex];
  
  // Shuffle players order but ensure imposter is not first
  let shuffledOrder = [...lobby.playersOrder];
  for (let i = shuffledOrder.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledOrder[i], shuffledOrder[j]] = [shuffledOrder[j], shuffledOrder[i]];
  }
  // If imposter is first, swap with a random other player
  if (shuffledOrder[0] === lobby.imposterId && shuffledOrder.length > 1) {
    const swapIndex = 1 + Math.floor(Math.random() * (shuffledOrder.length - 1));
    [shuffledOrder[0], shuffledOrder[swapIndex]] = [shuffledOrder[swapIndex], shuffledOrder[0]];
  }
  lobby.playersOrder = shuffledOrder;
  
  console.log('Selected word:', lobby.word);
  console.log('Imposter ID:', lobby.imposterId);
  
  for (const [playerId, player] of lobby.players.entries()) {
    player.isImposter = playerId === lobby.imposterId;
    player.clue = '';
    player.vote = null;
  }
  
  lobby.gameState = 'clues';
  lobby.currentClueIndex = 0;
  lobby.votes.clear();
  lobby.revealedImposter = null;
  
  for (const playerId of lobby.playersOrder) {
    const player = lobby.players.get(playerId);
    const wordToSend = player.isImposter ? null : lobby.word;
    console.log('Sending word to player', playerId, ':', player.isImposter ? 'IMPOSTER' : wordToSend);
    io.to(playerId).emit('imposterGameStarted', {
      word: wordToSend,
      isImposter: player.isImposter
    });
  }
  
  setTimeout(() => {
    broadcastImposterGameState(lobbyCode);
  }, 5000);
}

function broadcastImposterGameState(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const currentPlayerId = lobby.playersOrder[lobby.currentClueIndex];
  
  const playerData = Array.from(lobby.players.values()).map(p => ({
    id: p.id,
    name: p.name,
    clue: p.clue,
    vote: p.vote
  }));
  
  io.to(lobbyCode).emit('imposterGameState', {
    players: playerData,
    currentPlayerId: lobby.gameState === 'clues' ? currentPlayerId : null,
    gameState: lobby.gameState,
    revealedImposter: lobby.revealedImposter
  });
}

function nextImposterClue(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.currentClueIndex++;
  
  if (lobby.currentClueIndex >= lobby.playersOrder.length) {
    lobby.gameState = 'voting';
  }
  
  broadcastImposterGameState(lobbyCode);
}

function tallyImposterVotes(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const voteCounts = new Map();
  
  for (const player of lobby.players.values()) {
    if (player.vote) {
      voteCounts.set(player.vote, (voteCounts.get(player.vote) || 0) + 1);
    }
  }
  
  let maxVotes = 0;
  let votedOutId = null;
  
  for (const [playerId, count] of voteCounts.entries()) {
    if (count > maxVotes) {
      maxVotes = count;
      votedOutId = playerId;
    }
  }
  
  const votedOutPlayer = lobby.players.get(votedOutId);
  const imposterPlayer = lobby.players.get(lobby.imposterId);
  
  lobby.revealedImposter = {
    votedOutId,
    votedOutName: votedOutPlayer ? votedOutPlayer.name : 'Nobody',
    actualImposterId: lobby.imposterId,
    actualImposterName: imposterPlayer.name,
    word: lobby.word,
    playersGuessedCorrectly: votedOutId === lobby.imposterId
  };
  
  lobby.gameState = 'results';
  broadcastImposterGameState(lobbyCode);
}

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  
  socket.on('createBlackjackLobby', (data) => {
    const code = createBlackjackLobby(socket.id, data.name);
    socket.join(code);
    socket.emit('blackjackLobbyCreated', { code, isHost: true });
    io.to(code).emit('blackjackPlayersUpdate', Array.from(blackjackLobbies.get(code).players.values()).map(p => ({ id: p.id, name: p.name, money: p.money })));
  });
  
  socket.on('joinBlackjackLobby', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) {
      socket.emit('error', { message: 'Lobby not found' });
      return;
    }
    
    if (lobby.players.size >= 5) {
      socket.emit('error', { message: 'Lobby is full' });
      return;
    }
    
    lobby.players.set(socket.id, {
      id: socket.id,
      name: data.name,
      money: 1000,
      bet: 0,
      hand: [],
      status: 'waiting'
    });
    lobby.playersOrder.push(socket.id);
    
    socket.join(data.code);
    socket.emit('blackjackLobbyJoined', { code: data.code, isHost: false });
    io.to(data.code).emit('blackjackPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name, money: p.money })));
  });
  
  socket.on('startBlackjackGame', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id && lobby.players.size >= 1) {
      startBlackjackGame(data.code);
    }
  });
  
  socket.on('placeBet', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const player = lobby.players.get(socket.id);
    if (!player || player.money < data.amount || data.amount <= 0) {
      socket.emit('error', { message: 'Invalid bet' });
      return;
    }
    
    player.bet = data.amount;
    player.money -= data.amount;
    player.status = 'ready';
    
    const allReady = Array.from(lobby.players.values()).every(p => p.status === 'ready');
    
    if (allReady) {
      dealInitialCards(data.code);
    } else {
      io.to(data.code).emit('blackjackPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name, money: p.money, bet: p.bet, status: p.status })));
    }
  });
  
  socket.on('hit', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    player.hand.push(lobby.deck.pop());
    
    const handValue = calculateHandValue(player.hand);
    if (handValue > 21) {
      player.status = 'busted';
      nextBlackjackPlayer(data.code);
    } else {
      broadcastBlackjackGameState(data.code);
    }
  });
  
  socket.on('stand', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    player.status = 'standing';
    nextBlackjackPlayer(data.code);
  });
  
  socket.on('double', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    if (player.hand.length !== 2 || player.money < player.bet) {
      socket.emit('error', { message: 'Cannot double down' });
      return;
    }
    
    player.money -= player.bet;
    player.bet *= 2;
    player.hand.push(lobby.deck.pop());
    
    const handValue = calculateHandValue(player.hand);
    if (handValue > 21) {
      player.status = 'busted';
    } else {
      player.status = 'standing';
    }
    
    nextBlackjackPlayer(data.code);
  });
  
  socket.on('createImposterLobby', (data) => {
    const code = createImposterLobby(socket.id, data.name);
    socket.join(code);
    socket.emit('imposterLobbyCreated', { code, isHost: true });
    io.to(code).emit('imposterPlayersUpdate', Array.from(imposterLobbies.get(code).players.values()).map(p => ({ id: p.id, name: p.name })));
  });
  
  socket.on('joinImposterLobby', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (!lobby) {
      socket.emit('error', { message: 'Lobby not found' });
      return;
    }
    
    if (lobby.players.size >= 8) {
      socket.emit('error', { message: 'Lobby is full' });
      return;
    }
    
    lobby.players.set(socket.id, {
      id: socket.id,
      name: data.name,
      isImposter: false,
      clue: '',
      vote: null
    });
    lobby.playersOrder.push(socket.id);
    
    socket.join(data.code);
    socket.emit('imposterLobbyJoined', { code: data.code, isHost: false });
    io.to(data.code).emit('imposterPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name })));
  });
  
  socket.on('startImposterGame', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id && lobby.players.size >= 3) {
      startImposterGame(data.code);
    }
  });
  
  socket.on('submitClue', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (!lobby || lobby.gameState !== 'clues') return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentClueIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    player.clue = data.clue;
    
    nextImposterClue(data.code);
  });
  
  socket.on('submitVote', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (!lobby || lobby.gameState !== 'voting') return;
    
    const player = lobby.players.get(socket.id);
    player.vote = data.votedPlayerId;
    
    const allVoted = Array.from(lobby.players.values()).every(p => p.vote !== null);
    
    if (allVoted) {
      tallyImposterVotes(data.code);
    } else {
      broadcastImposterGameState(data.code);
    }
  });
  
  socket.on('restartImposterGame', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id) {
      startImposterGame(data.code);
    }
  });
  
  // ==================== YON SOCKET HANDLERS ====================
  
  socket.on('createYonLobby', (data) => {
    const code = createYonLobby(socket.id, data.name);
    socket.join(code);
    socket.emit('yonLobbyCreated', { code, isHost: true });
    io.to(code).emit('yonPlayersUpdate', Array.from(yonLobbies.get(code).players.values()).map(p => ({ id: p.id, name: p.name })));
  });
  
  socket.on('joinYonLobby', (data) => {
    const lobby = yonLobbies.get(data.code);
    if (!lobby) {
      socket.emit('error', { message: 'Lobby not found' });
      return;
    }
    
    if (lobby.players.size >= 8) {
      socket.emit('error', { message: 'Lobby is full' });
      return;
    }
    
    if (lobby.gameState !== 'lobby') {
      socket.emit('error', { message: 'Game already in progress' });
      return;
    }
    
    lobby.players.set(socket.id, { id: socket.id, name: data.name, hand: [] });
    lobby.playersOrder.push(socket.id);
    
    socket.join(data.code);
    socket.emit('yonLobbyJoined', { code: data.code, isHost: false });
    io.to(data.code).emit('yonPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name })));
  });
  
  socket.on('startYonGame', (data) => {
    const lobby = yonLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id && lobby.players.size >= 2) {
      startYonGame(data.code);
    }
  });
  
  socket.on('yonPlayCard', (data) => {
    const lobby = yonLobbies.get(data.code);
    if (!lobby || lobby.gameState !== 'playing') return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    const card = player.hand[data.cardIndex];
    if (!card) return;
    
    const topCard = lobby.discardPile[lobby.discardPile.length - 1];
    if (!canPlayYonCard(card, topCard, lobby.currentColor)) {
      socket.emit('error', { message: 'Cannot play this card' });
      return;
    }
    
    // Remove card from hand and add to discard pile
    player.hand.splice(data.cardIndex, 1);
    lobby.discardPile.push(card);
    
    // Set current color
    if (card.type === 'wild' || card.type === 'wild4') {
      lobby.currentColor = data.chosenColor || 'red';
    } else {
      lobby.currentColor = card.color;
    }
    
    // Check for winner
    const winner = checkYonWinner(data.code);
    if (winner) {
      endYonGame(data.code, winner);
      return;
    }
    
    // Handle special cards
    if (card.type === 'skip') {
      nextYonPlayer(data.code, 1); // Skip next player
    } else if (card.type === 'reverse') {
      if (lobby.playersOrder.length === 2) {
        // In 2-player game, reverse acts as skip
        nextYonPlayer(data.code, 1);
      } else {
        lobby.direction *= -1;
        nextYonPlayer(data.code, 0);
      }
    } else if (card.type === 'draw2') {
      nextYonPlayer(data.code, 0);
      const nextPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
      drawYonCards(data.code, nextPlayerId, 2);
      nextYonPlayer(data.code, 0); // Skip their turn
    } else if (card.type === 'wild4') {
      nextYonPlayer(data.code, 0);
      const nextPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
      drawYonCards(data.code, nextPlayerId, 4);
      nextYonPlayer(data.code, 0); // Skip their turn
    } else {
      nextYonPlayer(data.code, 0);
    }
    
    broadcastYonGameState(data.code);
  });
  
  socket.on('yonDrawCard', (data) => {
    const lobby = yonLobbies.get(data.code);
    if (!lobby || lobby.gameState !== 'playing') return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    drawYonCards(data.code, socket.id, 1);
    nextYonPlayer(data.code, 0);
    broadcastYonGameState(data.code);
  });
  
  socket.on('restartYonGame', (data) => {
    const lobby = yonLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id) {
      lobby.gameState = 'lobby';
      startYonGame(data.code);
    }
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    
    for (const [code, lobby] of blackjackLobbies.entries()) {
      if (lobby.players.has(socket.id)) {
        lobby.players.delete(socket.id);
        lobby.playersOrder = lobby.playersOrder.filter(id => id !== socket.id);
        
        if (lobby.players.size === 0) {
          blackjackLobbies.delete(code);
        } else {
          if (lobby.hostId === socket.id && lobby.players.size > 0) {
            lobby.hostId = lobby.playersOrder[0];
          }
          io.to(code).emit('blackjackPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name, money: p.money })));
        }
      }
    }
    
    for (const [code, lobby] of imposterLobbies.entries()) {
      if (lobby.players.has(socket.id)) {
        lobby.players.delete(socket.id);
        lobby.playersOrder = lobby.playersOrder.filter(id => id !== socket.id);
        
        if (lobby.players.size === 0) {
          imposterLobbies.delete(code);
        } else {
          if (lobby.hostId === socket.id && lobby.players.size > 0) {
            lobby.hostId = lobby.playersOrder[0];
          }
          io.to(code).emit('imposterPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name })));
        }
      }
    }
    
    for (const [code, lobby] of yonLobbies.entries()) {
      if (lobby.players.has(socket.id)) {
        lobby.players.delete(socket.id);
        lobby.playersOrder = lobby.playersOrder.filter(id => id !== socket.id);
        
        if (lobby.players.size === 0) {
          yonLobbies.delete(code);
        } else {
          if (lobby.hostId === socket.id && lobby.players.size > 0) {
            lobby.hostId = lobby.playersOrder[0];
          }
          if (lobby.gameState === 'lobby') {
            io.to(code).emit('yonPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name })));
          } else if (lobby.gameState === 'playing') {
            // Adjust current player index if needed
            if (lobby.currentPlayerIndex >= lobby.playersOrder.length) {
              lobby.currentPlayerIndex = 0;
            }
            broadcastYonGameState(code);
          }
        }
      }
    }
  });
});

// ==================== YON GAME FUNCTIONS ====================

const YON_COLORS = ['red', 'blue', 'green', 'yellow'];

function createYonDeck() {
  const deck = [];
  
  // Number cards (0-9) for each color
  for (const color of YON_COLORS) {
    // One 0 per color
    deck.push({ color, value: 0, type: 'number' });
    // Two of each 1-9 per color
    for (let i = 1; i <= 9; i++) {
      deck.push({ color, value: i, type: 'number' });
      deck.push({ color, value: i, type: 'number' });
    }
    // Two Skip, Reverse, Draw Two per color
    for (let i = 0; i < 2; i++) {
      deck.push({ color, value: 'skip', type: 'skip' });
      deck.push({ color, value: 'reverse', type: 'reverse' });
      deck.push({ color, value: 'draw2', type: 'draw2' });
    }
  }
  
  // Wild cards (4 of each)
  for (let i = 0; i < 4; i++) {
    deck.push({ color: null, value: 'wild', type: 'wild' });
    deck.push({ color: null, value: 'wild4', type: 'wild4' });
  }
  
  // Shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  
  return deck;
}

function createYonLobby(hostId, hostName) {
  const code = generateLobbyCode();
  yonLobbies.set(code, {
    code,
    hostId,
    players: new Map([[hostId, { id: hostId, name: hostName, hand: [] }]]),
    playersOrder: [hostId],
    gameState: 'lobby',
    deck: [],
    discardPile: [],
    currentPlayerIndex: 0,
    direction: 1, // 1 = clockwise, -1 = counter-clockwise
    currentColor: null
  });
  return code;
}

function startYonGame(lobbyCode) {
  const lobby = yonLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.deck = createYonDeck();
  lobby.discardPile = [];
  lobby.currentPlayerIndex = 0;
  lobby.direction = 1;
  lobby.gameState = 'playing';
  
  // Deal 7 cards to each player
  for (const player of lobby.players.values()) {
    player.hand = [];
    for (let i = 0; i < 7; i++) {
      player.hand.push(lobby.deck.pop());
    }
  }
  
  // Put first card on discard pile (make sure it's not a wild card)
  let firstCard = lobby.deck.pop();
  while (firstCard.type === 'wild' || firstCard.type === 'wild4') {
    lobby.deck.unshift(firstCard);
    firstCard = lobby.deck.pop();
  }
  lobby.discardPile.push(firstCard);
  lobby.currentColor = firstCard.color;
  
  broadcastYonGameState(lobbyCode);
}

function broadcastYonGameState(lobbyCode) {
  const lobby = yonLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const topCard = lobby.discardPile[lobby.discardPile.length - 1];
  const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
  
  // Send game state to each player (with their own hand)
  for (const [playerId, player] of lobby.players.entries()) {
    const playerData = Array.from(lobby.players.values()).map(p => ({
      id: p.id,
      name: p.name,
      cardCount: p.hand.length
    }));
    
    io.to(playerId).emit('yonGameState', {
      players: playerData,
      topCard,
      currentColor: lobby.currentColor,
      currentPlayerId,
      direction: lobby.direction,
      myHand: player.hand,
      cardsInDeck: lobby.deck.length
    });
  }
}

function canPlayYonCard(card, topCard, currentColor) {
  if (card.type === 'wild' || card.type === 'wild4') {
    return true;
  }
  if (card.color === currentColor) {
    return true;
  }
  if (card.value === topCard.value && card.type === topCard.type) {
    return true;
  }
  return false;
}

function nextYonPlayer(lobbyCode, skip = 0) {
  const lobby = yonLobbies.get(lobbyCode);
  if (!lobby) return;
  
  for (let i = 0; i <= skip; i++) {
    lobby.currentPlayerIndex += lobby.direction;
    if (lobby.currentPlayerIndex >= lobby.playersOrder.length) {
      lobby.currentPlayerIndex = 0;
    } else if (lobby.currentPlayerIndex < 0) {
      lobby.currentPlayerIndex = lobby.playersOrder.length - 1;
    }
  }
}

function drawYonCards(lobbyCode, playerId, count) {
  const lobby = yonLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const player = lobby.players.get(playerId);
  if (!player) return;
  
  for (let i = 0; i < count; i++) {
    if (lobby.deck.length === 0) {
      // Reshuffle discard pile into deck
      const topCard = lobby.discardPile.pop();
      lobby.deck = lobby.discardPile;
      lobby.discardPile = [topCard];
      for (let j = lobby.deck.length - 1; j > 0; j--) {
        const k = Math.floor(Math.random() * (j + 1));
        [lobby.deck[j], lobby.deck[k]] = [lobby.deck[k], lobby.deck[j]];
      }
    }
    if (lobby.deck.length > 0) {
      player.hand.push(lobby.deck.pop());
    }
  }
}

function checkYonWinner(lobbyCode) {
  const lobby = yonLobbies.get(lobbyCode);
  if (!lobby) return null;
  
  for (const player of lobby.players.values()) {
    if (player.hand.length === 0) {
      return player;
    }
  }
  return null;
}

function endYonGame(lobbyCode, winner) {
  const lobby = yonLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.gameState = 'finished';
  
  const standings = Array.from(lobby.players.values())
    .map(p => ({ id: p.id, name: p.name, cardCount: p.hand.length }))
    .sort((a, b) => a.cardCount - b.cardCount);
  
  io.to(lobbyCode).emit('yonGameOver', { standings });
}

const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});