const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

app.get('/blackjack', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/imposter', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'imposter.html'));
});

const blackjackLobbies = new Map();
const imposterLobbies = new Map();

const IMPOSTER_WORDS = [
  'Pizza', 'Coffee', 'Guitar', 'Ocean', 'Mountain', 'Sunset', 'Rainbow', 'Thunder',
  'Chocolate', 'Butterfly', 'Dragon', 'Castle', 'Wizard', 'Treasure', 'Diamond', 'Crown',
  'Phoenix', 'Unicorn', 'Vampire', 'Zombie', 'Robot', 'Spaceship', 'Planet', 'Galaxy',
  'Tornado', 'Volcano', 'Jungle', 'Desert', 'Iceberg', 'Waterfall', 'Forest', 'Beach',
  'Apple', 'Banana', 'Strawberry', 'Mango', 'Pineapple', 'Coconut', 'Lemon', 'Orange',
  'Tiger', 'Lion', 'Elephant', 'Giraffe', 'Penguin', 'Dolphin', 'Shark', 'Eagle',
  'Basketball', 'Football', 'Tennis', 'Hockey', 'Baseball', 'Swimming', 'Running', 'Cycling'
];

function generateLobbyCode() {
  return Math.random().toString(36).substring(2, 7).toUpperCase();
}

function createDeck() {
  const suits = ['♠', '♥', '♦', '♣'];
  const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck = [];
  
  for (let i = 0; i < 6; i++) {
    for (const suit of suits) {
      for (const value of values) {
        deck.push({ suit, value });
      }
    }
  }
  
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  
  return deck;
}

function getCardValue(card) {
  if (card.value === 'A') return 11;
  if (['J', 'Q', 'K'].includes(card.value)) return 10;
  return parseInt(card.value);
}

function calculateHandValue(hand) {
  let value = 0;
  let aces = 0;
  
  for (const card of hand) {
    const cardValue = getCardValue(card);
    value += cardValue;
    if (card.value === 'A') aces++;
  }
  
  while (value > 21 && aces > 0) {
    value -= 10;
    aces--;
  }
  
  return value;
}

function createBlackjackLobby(hostId, hostName) {
  const code = generateLobbyCode();
  blackjackLobbies.set(code, {
    code,
    hostId,
    players: new Map([[hostId, { id: hostId, name: hostName, money: 1000, bet: 0, hand: [], status: 'waiting' }]]),
    gameState: 'lobby',
    deck: [],
    dealerHand: [],
    currentPlayerIndex: 0,
    playersOrder: [hostId]
  });
  return code;
}

function startBlackjackGame(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.deck = createDeck();
  lobby.dealerHand = [];
  lobby.currentPlayerIndex = 0;
  lobby.gameState = 'betting';
  
  for (const player of lobby.players.values()) {
    player.hand = [];
    player.bet = 0;
    player.status = 'betting';
  }
  
  io.to(lobbyCode).emit('gameStarted', {
    gameState: 'betting'
  });
}

function dealInitialCards(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  for (const playerId of lobby.playersOrder) {
    const player = lobby.players.get(playerId);
    player.hand = [lobby.deck.pop(), lobby.deck.pop()];
    player.status = 'playing';
  }
  
  lobby.dealerHand = [lobby.deck.pop(), lobby.deck.pop()];
  lobby.gameState = 'playing';
  lobby.currentPlayerIndex = 0;
  
  broadcastBlackjackGameState(lobbyCode);
}

function broadcastBlackjackGameState(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
  
  const playerData = Array.from(lobby.players.values()).map(p => ({
    id: p.id,
    name: p.name,
    money: p.money,
    bet: p.bet,
    hand: p.hand,
    handValue: calculateHandValue(p.hand),
    status: p.status
  }));
  
  const dealerData = {
    hand: lobby.gameState === 'playing' ? [lobby.dealerHand[0], { suit: '?', value: '?' }] : lobby.dealerHand,
    handValue: lobby.gameState === 'results' ? calculateHandValue(lobby.dealerHand) : null
  };
  
  io.to(lobbyCode).emit('gameState', {
    players: playerData,
    dealer: dealerData,
    currentPlayerId: lobby.gameState === 'playing' ? currentPlayerId : null,
    gameState: lobby.gameState
  });
}

function nextBlackjackPlayer(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.currentPlayerIndex++;
  
  if (lobby.currentPlayerIndex >= lobby.playersOrder.length) {
    playDealerTurn(lobbyCode);
  } else {
    broadcastBlackjackGameState(lobbyCode);
  }
}

function playDealerTurn(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  let dealerValue = calculateHandValue(lobby.dealerHand);
  
  while (dealerValue < 17) {
    lobby.dealerHand.push(lobby.deck.pop());
    dealerValue = calculateHandValue(lobby.dealerHand);
  }
  
  resolveBlackjackRound(lobbyCode);
}

function resolveBlackjackRound(lobbyCode) {
  const lobby = blackjackLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const dealerValue = calculateHandValue(lobby.dealerHand);
  const dealerBusted = dealerValue > 21;
  
  for (const player of lobby.players.values()) {
    const playerValue = calculateHandValue(player.hand);
    const playerBusted = playerValue > 21;
    
    if (playerBusted) {
      player.status = 'lost';
    } else if (dealerBusted) {
      player.money += player.bet * 2;
      player.status = 'won';
    } else if (playerValue > dealerValue) {
      player.money += player.bet * 2;
      player.status = 'won';
    } else if (playerValue === dealerValue) {
      player.money += player.bet;
      player.status = 'push';
    } else {
      player.status = 'lost';
    }
  }
  
  lobby.gameState = 'results';
  broadcastBlackjackGameState(lobbyCode);
  
  setTimeout(() => {
    startBlackjackGame(lobbyCode);
  }, 5000);
}

function createImposterLobby(hostId, hostName) {
  const code = generateLobbyCode();
  imposterLobbies.set(code, {
    code,
    hostId,
    players: new Map([[hostId, { id: hostId, name: hostName, isImposter: false, clue: '', vote: null }]]),
    gameState: 'lobby',
    playersOrder: [hostId],
    word: '',
    imposterId: null,
    currentClueIndex: 0,
    votes: new Map(),
    revealedImposter: null
  });
  return code;
}

function startImposterGame(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.word = IMPOSTER_WORDS[Math.floor(Math.random() * IMPOSTER_WORDS.length)];
  const randomIndex = Math.floor(Math.random() * lobby.playersOrder.length);
  lobby.imposterId = lobby.playersOrder[randomIndex];
  
  for (const [playerId, player] of lobby.players.entries()) {
    player.isImposter = playerId === lobby.imposterId;
    player.clue = '';
    player.vote = null;
  }
  
  lobby.gameState = 'clues';
  lobby.currentClueIndex = 0;
  lobby.votes.clear();
  lobby.revealedImposter = null;
  
  for (const playerId of lobby.playersOrder) {
    const player = lobby.players.get(playerId);
    io.to(playerId).emit('imposterGameStarted', {
      word: player.isImposter ? 'You are the IMPOSTER!' : lobby.word,
      isImposter: player.isImposter
    });
  }
  
  broadcastImposterGameState(lobbyCode);
}

function broadcastImposterGameState(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const currentPlayerId = lobby.playersOrder[lobby.currentClueIndex];
  
  const playerData = Array.from(lobby.players.values()).map(p => ({
    id: p.id,
    name: p.name,
    clue: p.clue,
    vote: p.vote
  }));
  
  io.to(lobbyCode).emit('imposterGameState', {
    players: playerData,
    currentPlayerId: lobby.gameState === 'clues' ? currentPlayerId : null,
    gameState: lobby.gameState,
    revealedImposter: lobby.revealedImposter
  });
}

function nextImposterClue(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  lobby.currentClueIndex++;
  
  if (lobby.currentClueIndex >= lobby.playersOrder.length) {
    lobby.gameState = 'voting';
  }
  
  broadcastImposterGameState(lobbyCode);
}

function tallyImposterVotes(lobbyCode) {
  const lobby = imposterLobbies.get(lobbyCode);
  if (!lobby) return;
  
  const voteCounts = new Map();
  
  for (const player of lobby.players.values()) {
    if (player.vote) {
      voteCounts.set(player.vote, (voteCounts.get(player.vote) || 0) + 1);
    }
  }
  
  let maxVotes = 0;
  let votedOutId = null;
  
  for (const [playerId, count] of voteCounts.entries()) {
    if (count > maxVotes) {
      maxVotes = count;
      votedOutId = playerId;
    }
  }
  
  const votedOutPlayer = lobby.players.get(votedOutId);
  const imposterPlayer = lobby.players.get(lobby.imposterId);
  
  lobby.revealedImposter = {
    votedOutId,
    votedOutName: votedOutPlayer ? votedOutPlayer.name : 'Nobody',
    actualImposterId: lobby.imposterId,
    actualImposterName: imposterPlayer.name,
    word: lobby.word,
    playersGuessedCorrectly: votedOutId === lobby.imposterId
  };
  
  lobby.gameState = 'results';
  broadcastImposterGameState(lobbyCode);
}

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  
  socket.on('createBlackjackLobby', (data) => {
    const code = createBlackjackLobby(socket.id, data.name);
    socket.join(code);
    socket.emit('blackjackLobbyCreated', { code, isHost: true });
    io.to(code).emit('blackjackPlayersUpdate', Array.from(blackjackLobbies.get(code).players.values()).map(p => ({ id: p.id, name: p.name, money: p.money })));
  });
  
  socket.on('joinBlackjackLobby', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) {
      socket.emit('error', { message: 'Lobby not found' });
      return;
    }
    
    if (lobby.players.size >= 5) {
      socket.emit('error', { message: 'Lobby is full' });
      return;
    }
    
    lobby.players.set(socket.id, {
      id: socket.id,
      name: data.name,
      money: 1000,
      bet: 0,
      hand: [],
      status: 'waiting'
    });
    lobby.playersOrder.push(socket.id);
    
    socket.join(data.code);
    socket.emit('blackjackLobbyJoined', { code: data.code, isHost: false });
    io.to(data.code).emit('blackjackPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name, money: p.money })));
  });
  
  socket.on('startBlackjackGame', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id && lobby.players.size >= 2) {
      startBlackjackGame(data.code);
    }
  });
  
  socket.on('placeBet', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const player = lobby.players.get(socket.id);
    if (!player || player.money < data.amount || data.amount <= 0) {
      socket.emit('error', { message: 'Invalid bet' });
      return;
    }
    
    player.bet = data.amount;
    player.money -= data.amount;
    player.status = 'ready';
    
    const allReady = Array.from(lobby.players.values()).every(p => p.status === 'ready');
    
    if (allReady) {
      dealInitialCards(data.code);
    } else {
      io.to(data.code).emit('blackjackPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name, money: p.money, bet: p.bet, status: p.status })));
    }
  });
  
  socket.on('hit', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    player.hand.push(lobby.deck.pop());
    
    const handValue = calculateHandValue(player.hand);
    if (handValue > 21) {
      player.status = 'busted';
      nextBlackjackPlayer(data.code);
    } else {
      broadcastBlackjackGameState(data.code);
    }
  });
  
  socket.on('stand', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    player.status = 'standing';
    nextBlackjackPlayer(data.code);
  });
  
  socket.on('double', (data) => {
    const lobby = blackjackLobbies.get(data.code);
    if (!lobby) return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentPlayerIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    if (player.hand.length !== 2 || player.money < player.bet) {
      socket.emit('error', { message: 'Cannot double down' });
      return;
    }
    
    player.money -= player.bet;
    player.bet *= 2;
    player.hand.push(lobby.deck.pop());
    
    const handValue = calculateHandValue(player.hand);
    if (handValue > 21) {
      player.status = 'busted';
    } else {
      player.status = 'standing';
    }
    
    nextBlackjackPlayer(data.code);
  });
  
  socket.on('createImposterLobby', (data) => {
    const code = createImposterLobby(socket.id, data.name);
    socket.join(code);
    socket.emit('imposterLobbyCreated', { code, isHost: true });
    io.to(code).emit('imposterPlayersUpdate', Array.from(imposterLobbies.get(code).players.values()).map(p => ({ id: p.id, name: p.name })));
  });
  
  socket.on('joinImposterLobby', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (!lobby) {
      socket.emit('error', { message: 'Lobby not found' });
      return;
    }
    
    if (lobby.players.size >= 8) {
      socket.emit('error', { message: 'Lobby is full' });
      return;
    }
    
    lobby.players.set(socket.id, {
      id: socket.id,
      name: data.name,
      isImposter: false,
      clue: '',
      vote: null
    });
    lobby.playersOrder.push(socket.id);
    
    socket.join(data.code);
    socket.emit('imposterLobbyJoined', { code: data.code, isHost: false });
    io.to(data.code).emit('imposterPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name })));
  });
  
  socket.on('startImposterGame', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id && lobby.players.size >= 3) {
      startImposterGame(data.code);
    }
  });
  
  socket.on('submitClue', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (!lobby || lobby.gameState !== 'clues') return;
    
    const currentPlayerId = lobby.playersOrder[lobby.currentClueIndex];
    if (socket.id !== currentPlayerId) return;
    
    const player = lobby.players.get(socket.id);
    player.clue = data.clue;
    
    nextImposterClue(data.code);
  });
  
  socket.on('submitVote', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (!lobby || lobby.gameState !== 'voting') return;
    
    const player = lobby.players.get(socket.id);
    player.vote = data.votedPlayerId;
    
    const allVoted = Array.from(lobby.players.values()).every(p => p.vote !== null);
    
    if (allVoted) {
      tallyImposterVotes(data.code);
    } else {
      broadcastImposterGameState(data.code);
    }
  });
  
  socket.on('restartImposterGame', (data) => {
    const lobby = imposterLobbies.get(data.code);
    if (lobby && lobby.hostId === socket.id) {
      startImposterGame(data.code);
    }
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    
    for (const [code, lobby] of blackjackLobbies.entries()) {
      if (lobby.players.has(socket.id)) {
        lobby.players.delete(socket.id);
        lobby.playersOrder = lobby.playersOrder.filter(id => id !== socket.id);
        
        if (lobby.players.size === 0) {
          blackjackLobbies.delete(code);
        } else {
          if (lobby.hostId === socket.id && lobby.players.size > 0) {
            lobby.hostId = lobby.playersOrder[0];
          }
          io.to(code).emit('blackjackPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name, money: p.money })));
        }
      }
    }
    
    for (const [code, lobby] of imposterLobbies.entries()) {
      if (lobby.players.has(socket.id)) {
        lobby.players.delete(socket.id);
        lobby.playersOrder = lobby.playersOrder.filter(id => id !== socket.id);
        
        if (lobby.players.size === 0) {
          imposterLobbies.delete(code);
        } else {
          if (lobby.hostId === socket.id && lobby.players.size > 0) {
            lobby.hostId = lobby.playersOrder[0];
          }
          io.to(code).emit('imposterPlayersUpdate', Array.from(lobby.players.values()).map(p => ({ id: p.id, name: p.name })));
        }
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});