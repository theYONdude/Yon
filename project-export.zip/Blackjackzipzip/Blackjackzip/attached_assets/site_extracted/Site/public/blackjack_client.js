const socket = io();

let currentLobbyCode = null;
let myPlayerId = null;
let isHost = false;

const screens = {
  lobby: document.getElementById('lobby-screen'),
  waiting: document.getElementById('waiting-screen'),
  betting: document.getElementById('betting-screen'),
  game: document.getElementById('game-screen'),
  results: document.getElementById('results-screen')
};

function showScreen(screenName) {
  Object.values(screens).forEach(screen => screen.classList.add('hidden'));
  screens[screenName].classList.remove('hidden');
}

document.getElementById('create-lobby-btn').addEventListener('click', () => {
  const name = document.getElementById('player-name').value.trim();
  if (!name) {
    alert('Please enter your name');
    return;
  }
  socket.emit('createBlackjackLobby', { name });
});

document.getElementById('join-lobby-btn').addEventListener('click', () => {
  const name = document.getElementById('player-name').value.trim();
  const code = document.getElementById('lobby-code-input').value.trim().toUpperCase();
  if (!name || !code) {
    alert('Please enter your name and lobby code');
    return;
  }
  socket.emit('joinBlackjackLobby', { name, code });
});

document.getElementById('start-game-btn').addEventListener('click', () => {
  socket.emit('startBlackjackGame', { code: currentLobbyCode });
});

document.getElementById('place-bet-btn').addEventListener('click', () => {
  const amount = parseInt(document.getElementById('bet-input').value);
  if (!amount || amount <= 0) {
    alert('Please enter a valid bet amount');
    return;
  }
  socket.emit('placeBet', { code: currentLobbyCode, amount });
  document.getElementById('place-bet-btn').disabled = true;
  document.getElementById('bet-input').disabled = true;
});

document.getElementById('hit-btn').addEventListener('click', () => {
  socket.emit('hit', { code: currentLobbyCode });
});

document.getElementById('stand-btn').addEventListener('click', () => {
  socket.emit('stand', { code: currentLobbyCode });
});

document.getElementById('double-btn').addEventListener('click', () => {
  socket.emit('double', { code: currentLobbyCode });
});

socket.on('blackjackLobbyCreated', (data) => {
  currentLobbyCode = data.code;
  myPlayerId = socket.id;
  isHost = data.isHost;
  document.getElementById('display-lobby-code').textContent = data.code;
  document.getElementById('start-game-btn').classList.remove('hidden');
  document.querySelector('.waiting-text').classList.add('hidden');
  showScreen('waiting');
});

socket.on('blackjackLobbyJoined', (data) => {
  currentLobbyCode = data.code;
  myPlayerId = socket.id;
  isHost = data.isHost;
  document.getElementById('display-lobby-code').textContent = data.code;
  if (isHost) {
    document.getElementById('start-game-btn').classList.remove('hidden');
    document.querySelector('.waiting-text').classList.add('hidden');
  }
  showScreen('waiting');
});

socket.on('blackjackPlayersUpdate', (players) => {
  const playersList = document.getElementById('players-list');
  const betPlayersList = document.getElementById('bet-players-list');
  
  playersList.innerHTML = '';
  betPlayersList.innerHTML = '';
  
  players.forEach(player => {
    const div = document.createElement('div');
    div.className = 'player-item';
    div.innerHTML = `
      <span>${player.name} ${player.id === myPlayerId ? '(You)' : ''}</span>
      <span>$${player.money}</span>
    `;
    playersList.appendChild(div);
    
    const betDiv = document.createElement('div');
    betDiv.className = 'player-item';
    betDiv.innerHTML = `
      <span>${player.name} ${player.id === myPlayerId ? '(You)' : ''}</span>
      <span>${player.status === 'ready' ? '✓ Ready' : 'Betting...'}</span>
    `;
    betPlayersList.appendChild(betDiv);
  });
  
  if (isHost && players.length < 2) {
    document.getElementById('start-game-btn').disabled = true;
  } else if (isHost) {
    document.getElementById('start-game-btn').disabled = false;
  }
});

socket.on('gameStarted', (data) => {
  showScreen('betting');
  document.getElementById('bet-input').disabled = false;
  document.getElementById('place-bet-btn').disabled = false;
  document.getElementById('bet-input').value = '';
  
  socket.emit('getPlayers', { code: currentLobbyCode });
});

socket.on('gameState', (data) => {
  const myPlayer = data.players.find(p => p.id === myPlayerId);
  
  if (data.gameState === 'playing') {
    showScreen('game');
    document.getElementById('bet-balance').textContent = myPlayer.money;
    renderGameState(data);
  } else if (data.gameState === 'results') {
    showScreen('results');
    renderResults(data);
  }
});

function renderGameState(data) {
  renderDealer(data.dealer, 'dealer-hand', 'dealer-value');
  renderPlayers(data.players, data.currentPlayerId);
  
  const myPlayer = data.players.find(p => p.id === myPlayerId);
  const isMyTurn = data.currentPlayerId === myPlayerId;
  const actionsPanel = document.getElementById('actions-panel');
  
  if (isMyTurn && myPlayer.status === 'playing') {
    actionsPanel.classList.remove('hidden');
    document.getElementById('hit-btn').disabled = false;
    document.getElementById('stand-btn').disabled = false;
    document.getElementById('double-btn').disabled = myPlayer.hand.length !== 2 || myPlayer.money < myPlayer.bet;
  } else {
    actionsPanel.classList.add('hidden');
  }
}

function renderResults(data) {
  renderDealer(data.dealer, 'results-dealer-hand', 'results-dealer-value');
  renderPlayersResults(data.players);
}

function renderDealer(dealer, handId, valueId) {
  const dealerHandEl = document.getElementById(handId);
  const dealerValueEl = document.getElementById(valueId);
  
  dealerHandEl.innerHTML = '';
  dealer.hand.forEach(card => {
    const cardEl = createCardElement(card);
    dealerHandEl.appendChild(cardEl);
  });
  
  if (dealer.handValue !== null) {
    dealerValueEl.textContent = `Value: ${dealer.handValue}`;
  } else {
    dealerValueEl.textContent = '';
  }
}

function renderPlayers(players, currentPlayerId) {
  const playersSection = document.getElementById('players-section');
  playersSection.innerHTML = '';
  
  players.forEach(player => {
    const playerBox = document.createElement('div');
    playerBox.className = 'player-box';
    
    if (player.id === currentPlayerId && player.status === 'playing') {
      playerBox.classList.add('active');
    }
    
    const handHtml = player.hand.map(card => createCardElement(card).outerHTML).join('');
    
    let statusText = '';
    if (player.status === 'busted') statusText = 'BUSTED!';
    else if (player.status === 'standing') statusText = 'Standing';
    else if (player.status === 'playing' && player.id === currentPlayerId) statusText = 'Your Turn';
    else if (player.status === 'playing') statusText = 'Playing...';
    
    playerBox.innerHTML = `
      <div class="player-info">
        <span class="player-name">${player.name}${player.id === myPlayerId ? ' (You)' : ''}</span>
        <span class="player-money">$${player.money}</span>
      </div>
      <div class="player-bet">Bet: $${player.bet}</div>
      <div class="hand">${handHtml}</div>
      <div class="hand-value">Value: ${player.handValue}</div>
      <div class="player-status">${statusText}</div>
    `;
    
    playersSection.appendChild(playerBox);
  });
}

function renderPlayersResults(players) {
  const playersSection = document.getElementById('results-players-section');
  playersSection.innerHTML = '';
  
  players.forEach(player => {
    const playerBox = document.createElement('div');
    playerBox.className = 'player-box';
    
    if (player.status === 'won') playerBox.classList.add('won');
    else if (player.status === 'lost') playerBox.classList.add('lost');
    else if (player.status === 'push') playerBox.classList.add('push');
    
    const handHtml = player.hand.map(card => createCardElement(card).outerHTML).join('');
    
    let statusText = '';
    if (player.status === 'won') statusText = 'WON! 🎉';
    else if (player.status === 'lost') statusText = 'Lost';
    else if (player.status === 'push') statusText = 'Push';
    
    playerBox.innerHTML = `
      <div class="player-info">
        <span class="player-name">${player.name}${player.id === myPlayerId ? ' (You)' : ''}</span>
        <span class="player-money">$${player.money}</span>
      </div>
      <div class="player-bet">Bet: $${player.bet}</div>
      <div class="hand">${handHtml}</div>
      <div class="hand-value">Value: ${player.handValue}</div>
      <div class="player-status">${statusText}</div>
    `;
    
    playersSection.appendChild(playerBox);
  });
}

function createCardElement(card) {
  if (card.suit === '?') {
    const cardBack = document.createElement('div');
    cardBack.className = 'card-back';
    cardBack.textContent = '?';
    return cardBack;
  }
  
  const cardEl = document.createElement('div');
  cardEl.className = 'card';
  if (card.suit === '♥' || card.suit === '♦') {
    cardEl.classList.add('red');
  }
  
  cardEl.innerHTML = `
    <div>${card.value}</div>
    <div class="card-suit">${card.suit}</div>
  `;
  
  return cardEl;
}

socket.on('error', (data) => {
  alert(data.message);
});